import json
from pymilvus import Collection, utility, DataType
from milvus_client import MilvusClient
import argparse

class MilvusView:
    def __init__(self):
        self.milvus_client = MilvusClient()
        self.milvus_client.connect()

    def print_collection_data_as_json(self, collection_name: str):
        """
        Prints all data from a specified Milvus collection as JSON output.
        """
        try:
            if not utility.has_collection(collection_name):
                print(f"Error: Collection '{collection_name}' does not exist.")
                return

            collection = Collection(collection_name)
            collection.load()

            # Get all entity IDs in the collection
            # This approach might be inefficient for very large collections.
            # A more robust solution would involve iterating through segments or using a more advanced query.
            # For demonstration, we'll query a large number of entities.
            
            # Determine output fields dynamically
            output_fields = [field.name for field in collection.schema.fields if field.name != "embedding" and field.dtype != DataType.FLOAT_VECTOR]
            
            if not output_fields:
                print(f"Collection '{collection_name}' has no printable fields (only vector fields found).")
                return

            # Query all entities (up to a limit)
            # Adjust limit as needed, or implement pagination for very large collections
            results = collection.query(
                expr="id > 0", # Query all entities with id > 0
                output_fields=output_fields,
                limit=16384 # Max limit for a single query
            )

            print(json.dumps(results, indent=4))

        except Exception as e:
            print(f"An error occurred: {e}")
        finally:
            self.milvus_client.disconnect()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="View Milvus collection data as JSON.")
    parser.add_argument("collection_name", type=str, help="The name of the Milvus collection to view.")
    args = parser.parse_args()

    viewer = MilvusView()
    viewer.print_collection_data_as_json(args.collection_name)
