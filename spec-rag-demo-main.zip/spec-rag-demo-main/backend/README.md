# RAG Chatbot Backend

Python FastAPI backend for the RAG Chatbot application.

## Setup

1. Install dependencies:
```bash
cd backend
pip install -r requirements.txt
```

2. Configure environment variables:
Create a `.env` file in the backend directory with the following:
```
MILVUS_HOST=localhost
MILVUS_PORT=19530
GEMINI_API_KEY=your_gemini_api_key
```

3. Ensure Milvus is running:
```bash
docker run -d --name milvus-standalone -p 19530:19530 -p 9091:9091 milvusdb/milvus:latest
```

## Run the Server

```bash
cd backend
python main.py
```

The API will be available at `http://localhost:8000`

## API Endpoints

- `POST /chat/new` - Create a new chat session
- `POST /chat` - Send a message and get RAG response
- `POST /upload` - Upload a PDF document (returns immediately with UUID and processing status)
- `GET /chat/{chat_id}/history` - Get chat history for a session
- `GET /content/{content_uuid}/status` - Get status of uploaded content

## Architecture

### Components

1. **ai_model.py** - Abstract AI model wrapper class
   - `embed(text)` - Generate embeddings for text
   - `embed_batch(texts)` - Batch embedding generation
   - `chat(messages, context)` - Generate chat responses with context
   - Includes GeminiModel (fully implemented) and OpenAIModel template

2. **milvus_client.py** - Milvus vector database wrapper
   - Collection management (docs_vector, chat_history, contents)
   - Vector insertion with metadata and content UUID
   - Similarity search for RAG
   - Chat history storage and retrieval
   - Content management (save, update status, retrieve)

3. **document_processor.py** - PDF processing pipeline
   - Text extraction from PDFs
   - Text chunking with overlap
   - Async batch embedding and storage

4. **main.py** - FastAPI application
   - Chat endpoints with RAG
   - Document upload with background processing
   - CORS configuration

## Implementation Notes

### AI Model Integration

The `ai_model.py` file contains:

1. **GeminiModel** - Fully implemented Google Gemini integration (default)
   - Uses `models/embedding-001` for embeddings (768 dimensions)
   - Uses `gemini-pro` for chat completions
   - Embeddings configured for retrieval tasks

2. **OpenAIModel** - Template implementation for OpenAI
   - Can be implemented if you prefer OpenAI over Gemini

### RAG Pipeline

1. User sends a message
2. Message is embedded using AI model
3. Milvus searches for similar document chunks
4. Top results are formatted as context
5. Context + chat history sent to AI model
6. Response saved to Milvus chat history
7. Response returned with sources

### Document Processing

**Upload Flow:**
1. User uploads PDF via multipart form with optional metadata JSON
2. Backend immediately saves PDF to `contents` collection with status "processing"
3. Returns response with content UUID and status to user
4. Background async task starts:
   - Extracts text from PDF pages
   - Chunks text with overlap
   - Generates embeddings for all chunks
   - Stores vectors in `docs_vector` collection with content UUID
   - Updates content status to "completed" (or "failed" on error)

**Status Tracking:**
- User receives immediate confirmation with UUID
- Can query `/content/{uuid}/status` to check processing status
- All vectors linked to original content via content_uuid

### Milvus Collections

The system uses three Milvus collections:

1. **docs_vector** - Document vectors and content (renamed from specs)
   - `embedding` - 768-dimensional vectors (Gemini embedding-001)
   - `text` - Chunk text
   - `filename` - Source filename
   - `page_number` - PDF page number
   - `metadata` - JSON metadata
   - `content_uuid` - Reference to contents collection
   - Index: HNSW (M=16, efConstruction=200)

2. **chat_history** - Chat conversation history
   - `message_id` - Unique message identifier
   - `chat_id` - Chat session identifier
   - `user_query` - User's question
   - `model_response` - AI's response
   - `timestamp` - Unix timestamp in milliseconds

3. **contents** - Uploaded file storage
   - `content_uuid` - Unique content identifier
   - `filename` - Original filename
   - `base64_content` - Base64-encoded PDF file
   - `status` - Processing status (processing, completed, failed)
   - `created_at` - Unix timestamp in milliseconds

### Vector Index

The system uses HNSW (Hierarchical Navigable Small World) index for vector similarity search:
- **Index Type**: HNSW
- **Metric**: L2 (Euclidean distance)
- **Parameters**:
  - M=16: Maximum number of connections per layer
  - efConstruction=200: Size of dynamic candidate list during construction
  - ef=100: Size of dynamic candidate list during search

HNSW provides excellent query performance with high recall rates, making it ideal for production RAG systems.
