from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    milvus_host: str = "localhost"
    milvus_port: int = 19530
    gemini_api_key: Optional[str] = None

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
