from pymilvus import connections, Collection, FieldSchema, CollectionSchema, DataType, utility
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid
import base64
import time # This import is no longer needed
from config import settings


class MilvusClient:
    def __init__(self, collection_name: str = "docs_vector"):
        self.collection_name = collection_name
        self.chat_collection_name = "chat_history"
        self.contents_collection_name = "contents"
        self.sys_prompts_collection_name = "sys_prompts"
        self.collection = None
        self.chat_collection = None
        self.contents_collection = None
        self.sys_prompts_collection = None
        self.dim = 768

    def connect(self):
        """Connect to Milvus server"""
        connections.connect(
            alias="default",
            host=settings.milvus_host,
            port=settings.milvus_port
        )

    def create_collection(self):
        """Create docs_vector collection if it doesn't exist"""
        if utility.has_collection(self.collection_name):
            self.collection = Collection(self.collection_name)
            self.collection.load() # Load existing collection
            return

        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=self.dim),
            FieldSchema(name="text", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="filename", dtype=DataType.VARCHAR, max_length=500),
            FieldSchema(name="page_number", dtype=DataType.INT64),
            FieldSchema(name="metadata", dtype=DataType.VARCHAR, max_length=2000),
            FieldSchema(name="content_uuid", dtype=DataType.VARCHAR, max_length=100),
        ]

        schema = CollectionSchema(fields=fields, description="Document vectors collection for RAG")
        self.collection = Collection(name=self.collection_name, schema=schema)

        index_params = {
            "metric_type": "L2",
            "index_type": "HNSW",
            "params": {
                "M": 16,
                "efConstruction": 200
            }
        }
        self.collection.create_index(field_name="embedding", index_params=index_params)
        self.collection.load()

    def create_chat_history_collection(self):
        """Create chat history collection if it doesn't exist or needs recreation"""
        if utility.has_collection(self.chat_collection_name):
            self.chat_collection = Collection(self.chat_collection_name)
            self.chat_collection.load() # Load existing collection
            return
  
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="message_id", dtype=DataType.VARCHAR, max_length=100),
            FieldSchema(name="chat_id", dtype=DataType.VARCHAR, max_length=100),
            FieldSchema(name="user_query", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="model_response", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="agent", dtype=DataType.VARCHAR, max_length=50),
            FieldSchema(name="spec_id", dtype=DataType.VARCHAR, max_length=100),
            FieldSchema(name="timestamp", dtype=DataType.INT64),
            FieldSchema(name="dummy_vector", dtype=DataType.FLOAT_VECTOR, dim=2), # Added dummy vector field
        ]

        schema = CollectionSchema(fields=fields, description="Chat history collection")
        self.chat_collection = Collection(name=self.chat_collection_name, schema=schema)

        # Create a dummy index for the dummy_vector field
        index_params = {
            "metric_type": "L2",
            "index_type": "FLAT",
            "params": {}
        }
        self.chat_collection.create_index(field_name="dummy_vector", index_params=index_params)
        self.chat_collection.load() # Load the collection after creation

    def create_contents_collection(self):
        """Create contents collection if it doesn't exist or needs recreation"""
        if utility.has_collection(self.contents_collection_name):
            self.contents_collection = Collection(self.contents_collection_name)
            self.contents_collection.load() # Load existing collection
            return
 
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="content_uuid", dtype=DataType.VARCHAR, max_length=100, is_primary_key=False),
            FieldSchema(name="filename", dtype=DataType.VARCHAR, max_length=500),
            FieldSchema(name="status", dtype=DataType.VARCHAR, max_length=50),
            FieldSchema(name="created_at", dtype=DataType.INT64),
            FieldSchema(name="dummy_vector", dtype=DataType.FLOAT_VECTOR, dim=2), # Added dummy vector field
        ]

        schema = CollectionSchema(fields=fields, description="Contents collection for uploaded files")
        self.contents_collection = Collection(name=self.contents_collection_name, schema=schema)

        # Create a dummy index for the dummy_vector field
        index_params = {
            "metric_type": "L2",
            "index_type": "FLAT",
            "params": {}
        }
        self.contents_collection.create_index(field_name="dummy_vector", index_params=index_params)
        self.contents_collection.load() # Load the collection after creation

    def create_sys_prompts_collection(self):

        if utility.has_collection(self.sys_prompts_collection_name):
            self.sys_prompts_collection = Collection(self.sys_prompts_collection_name)
            self.sys_prompts_collection.load() # Load existing collection
            return

        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="prompt_uuid", dtype=DataType.VARCHAR, max_length=100),
            FieldSchema(name="name", dtype=DataType.VARCHAR, max_length=500),
            FieldSchema(name="prompt_text", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="created_at", dtype=DataType.INT64),
            FieldSchema(name="dummy_vector", dtype=DataType.FLOAT_VECTOR, dim=2), # Added dummy vector field
        ]

        schema = CollectionSchema(fields=fields, description="System prompts collection")
        self.sys_prompts_collection = Collection(name=self.sys_prompts_collection_name, schema=schema)

        # Create a dummy index for the dummy_vector field
        index_params = {
            "metric_type": "L2",
            "index_type": "FLAT",
            "params": {}
        }
        self.sys_prompts_collection.create_index(field_name="dummy_vector", index_params=index_params)
        self.sys_prompts_collection.load() # Load the collection after creation

    def save_content(self, filename: str, file_content: bytes) -> str:
        """Save file content to contents collection and return UUID"""
        content_uuid = str(uuid.uuid4())
        base64_content = base64.b64encode(file_content).decode('utf-8')
        timestamp = int(datetime.utcnow().timestamp() * 1000)

        entities = [
            [content_uuid],
            [filename],
            ["processing"], # Removed base64_content
            [timestamp]
        ]

        self.contents_collection.insert(entities)
        self.contents_collection.flush()

        return content_uuid

    def update_content_status(self, content_uuid: str, status: str) -> bool:
        """Update the status of a content by UUID"""
        try:
            self.contents_collection.load()

            expr = f'content_uuid == "{content_uuid}"'
            results = self.contents_collection.query(
                expr=expr,
                output_fields=["id"]
            )

            if not results:
                return False

            self.contents_collection.delete(expr)
            self.contents_collection.flush()

            return True
        except Exception as e:
            print(f"Error updating content status: {e}")
            return False

    def get_content_by_uuid(self, content_uuid: str) -> Optional[Dict[str, Any]]:
        """Retrieve content by UUID"""
        self.contents_collection.load()

        expr = f'content_uuid == "{content_uuid}"'
        results = self.contents_collection.query(
            expr=expr,
            output_fields=["content_uuid", "filename", "status", "created_at"] # base64_content already removed
        )

        if results:
            return results[0]
        return None

    def list_contents(self, status_filter: Optional[str] = None, search_query: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all contents with optional filtering"""
        self.contents_collection.load()

        expr_parts = []

        if status_filter and status_filter != "all":
            expr_parts.append(f'status == "{status_filter}"')

        if search_query:
            expr_parts.append(f'filename like "%{search_query}%"')

        expr = " && ".join(expr_parts) if expr_parts else ""

        try:
            if expr:
                results = self.contents_collection.query(
                    expr=expr,
                    output_fields=["content_uuid", "filename", "status", "created_at"], # base64_content already removed
                    limit=1000
                )
            else:
                results = self.contents_collection.query(
                    expr="id > 0",
                    output_fields=["content_uuid", "filename", "status", "created_at"], # base64_content already removed
                    limit=1000
                )

            sorted_results = sorted(results, key=lambda x: x["created_at"], reverse=True)
            return sorted_results
        except Exception as e:
            print(f"Error listing contents: {e}")
            return []

    def delete_content(self, content_uuid: str) -> bool:
        """Delete content and all associated embeddings"""
        try:
            self.contents_collection.load()
            self.collection.load()

            content_expr = f'content_uuid == "{content_uuid}"'

            self.collection.delete(content_expr)
            self.collection.flush()

            self.contents_collection.delete(content_expr)
            self.contents_collection.flush()

            return True
        except Exception as e:
            print(f"Error deleting content: {e}")
            return False

    def create_system_prompt(self, name: str, prompt_text: str) -> str:
        """Create a new system prompt"""
        self.sys_prompts_collection.load()

        prompt_uuid = str(uuid.uuid4())
        timestamp = int(datetime.utcnow().timestamp() * 1000)

        entities = [
            [prompt_uuid],
            [name],
            [prompt_text],
            [timestamp],
            [[0.0, 0.0]]
        ]

        self.sys_prompts_collection.insert(entities)
        self.sys_prompts_collection.flush()

        return prompt_uuid

    def list_system_prompts(self, search_query: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all system prompts with optional search"""
        self.sys_prompts_collection.load()

        try:
            if search_query:
                expr = f'name like "%{search_query}%"'
                results = self.sys_prompts_collection.query(
                    expr=expr,
                    output_fields=["prompt_uuid", "name", "prompt_text", "created_at"],
                    limit=1000
                )
            else:
                results = self.sys_prompts_collection.query(
                    expr="id > 0",
                    output_fields=["prompt_uuid", "name", "prompt_text", "created_at"],
                    limit=1000
                )

            sorted_results = sorted(results, key=lambda x: x["created_at"], reverse=True)
            return sorted_results
        except Exception as e:
            print(f"Error listing system prompts: {e}")
            return []

    def get_system_prompt(self, prompt_uuid: str) -> Optional[Dict[str, Any]]:
        """Get a system prompt by UUID"""
        self.sys_prompts_collection.load()

        expr = f'prompt_uuid == "{prompt_uuid}"'
        results = self.sys_prompts_collection.query(
            expr=expr,
            output_fields=["prompt_uuid", "name", "prompt_text", "created_at"]
        )

        if results:
            return results[0]
        return None
    
    def update_system_prompt(self, prompt_uuid: str, name: str, prompt_text: str) -> bool:
        """Update a system prompt by UUID"""
        try:
            self.sys_prompts_collection.load()

            # Check if prompt exists
            expr = f'prompt_uuid == "{prompt_uuid}"'
            results = self.sys_prompts_collection.query(
                expr=expr,
                output_fields=["prompt_uuid"]
            )

            if not results:
                return False

            # Delete old prompt
            self.sys_prompts_collection.delete(expr)

            # Insert updated prompt
            entity = [
                [prompt_uuid],
                [name],
                [prompt_text],
                [int(datetime.utcnow().timestamp() * 1000)],
                [[0.0, 0.0]] # Add dummy vector
            ]
            self.sys_prompts_collection.insert(entity)
            self.sys_prompts_collection.flush()

            return True
        except Exception as e:
            print(f"Error updating system prompt: {e}")
            return False

    def delete_system_prompt(self, prompt_uuid: str) -> bool:
        """Delete a system prompt"""
        try:
            self.sys_prompts_collection.load()

            expr = f'prompt_uuid == "{prompt_uuid}"'
            self.sys_prompts_collection.delete(expr)
            self.sys_prompts_collection.flush()

            return True
        except Exception as e:
            print(f"Error deleting system prompt: {e}")
            return False

    def insert(self, embeddings: List[List[float]], texts: List[str],
               filenames: List[str], page_numbers: List[int],
               metadata: List[str], content_uuids: List[str]):
        """Insert vectors and metadata into docs_vector collection"""
        entities = [
            embeddings,
            texts,
            filenames,
            page_numbers,
            metadata,
            content_uuids
        ]

        self.collection.insert(entities)
        self.collection.flush()

    def search(self, query_embedding: List[float], top_k: int = 5) -> List[Dict[str, Any]]:
        """Search for similar vectors in docs_vector collection"""
        self.collection.load()

        search_params = {
            "metric_type": "L2",
            "params": {"ef": 100}
        }

        results = self.collection.search(
            data=[query_embedding],
            anns_field="embedding",
            param=search_params,
            limit=top_k,
            output_fields=["text", "filename", "page_number", "metadata", "content_uuid"]
        )

        search_results = []
        for hits in results:
            for hit in hits:
                search_results.append({
                    "text": hit.entity.get("text"),
                    "filename": hit.entity.get("filename"),
                    "page_number": hit.entity.get("page_number"),
                    "metadata": hit.entity.get("metadata"),
                    "content_uuid": hit.entity.get("content_uuid"),
                    "distance": hit.distance
                })

        return search_results

    def save_chat_message(self, chat_id: str, user_query: str, model_response: str, agent: str = "RAG", spec_id: str = "") -> Dict[str, Any]:
        """Save a chat message to chat history collection"""
        message_id = str(uuid.uuid4())
        timestamp = int(datetime.utcnow().timestamp() * 1000)

        entities = [
            [message_id],
            [chat_id],
            [user_query],
            [model_response],
            [agent],
            [spec_id],
            [timestamp]
        ]

        self.chat_collection.insert(entities)
        self.chat_collection.flush()

        return {
            "message_id": message_id,
            "chat_id": chat_id,
            "user_query": user_query,
            "model_response": model_response,
            "agent": agent,
            "spec_id": spec_id,
            "timestamp": timestamp
        }

    def get_chat_history(self, chat_id: str) -> List[Dict[str, Any]]:
        """Retrieve chat history for a specific chat session"""
        self.chat_collection.load()

        expr = f'chat_id == "{chat_id}"'
        results = self.chat_collection.query(
            expr=expr,
            output_fields=["message_id", "chat_id", "user_query", "model_response", "agent", "spec_id", "timestamp"]
        )

        sorted_results = sorted(results, key=lambda x: x["timestamp"])

        return sorted_results

    def get_all_chat_sessions(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Retrieve list of unique chat sessions with their first message"""
        self.chat_collection.load()

        all_messages = self.chat_collection.query(
            expr="chat_id != ''",
            output_fields=["chat_id", "user_query", "timestamp"],
            limit=16384
        )

        chat_sessions = {}
        for msg in all_messages:
            chat_id = msg["chat_id"]
            if chat_id not in chat_sessions or msg["timestamp"] < chat_sessions[chat_id]["first_timestamp"]:
                chat_name = msg["user_query"][:30] + ("..." if len(msg["user_query"]) > 30 else "")
                if chat_id not in chat_sessions:
                    chat_sessions[chat_id] = {
                        "chat_id": chat_id,
                        "chat_name": chat_name,
                        "first_timestamp": msg["timestamp"],
                        "last_timestamp": msg["timestamp"]
                    }
                else:
                    chat_sessions[chat_id]["first_timestamp"] = min(chat_sessions[chat_id]["first_timestamp"], msg["timestamp"])
                    chat_sessions[chat_id]["last_timestamp"] = max(chat_sessions[chat_id]["last_timestamp"], msg["timestamp"])

        sessions_list = list(chat_sessions.values())
        sessions_list.sort(key=lambda x: x["last_timestamp"], reverse=True)

        return sessions_list[:limit]

    def generate_chat_id(self) -> str:
        """Generate a new unique chat ID"""
        return str(uuid.uuid4())

    def print_all_collections(self):
        """Print all existing collections in Milvus"""
        try:
            self.connect()
            collections = utility.list_collections()
            print("Existing Milvus Collections:")
            for collection_name in collections:
                print(f"- {collection_name}")
        except Exception as e:
            print(f"Error listing collections: {e}")
        finally:
            self.disconnect()

    def disconnect(self):
        """Disconnect from Milvus"""
        connections.disconnect(alias="default")
