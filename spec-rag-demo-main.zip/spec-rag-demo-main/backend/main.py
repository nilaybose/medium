from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import json
from fastapi.responses import JSONResponse

from config import settings
from milvus_client import MilvusClient
from ai_model import get_ai_model
from document_processor import process_document_async

app = FastAPI(title="RAG Chatbot API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize clients
milvus_client = MilvusClient()
milvus_client.print_all_collections()
ai_model = get_ai_model("gemini", api_key=settings.gemini_api_key)


# Request/Response Models
class ChatRequest(BaseModel):
    chat_id: str
    message: str
    system_prompt_uuid: Optional[str] = None
    agent: str = "RAG"
    spec_id: Optional[str] = None


class ChatResponse(BaseModel):
    chat_id: str
    response: str
    sources: list[Dict[str, Any]]
    charts: Optional[List[Dict[str, Any]]] = None
    attachments: Optional[List[Dict[str, str]]] = None


class NewChatResponse(BaseModel):
    chat_id: str


class UploadResponse(BaseModel):
    success: bool
    message: str
    filename: str
    content_uuid: str
    status: str


class SystemPromptRequest(BaseModel):
    name: str
    prompt_text: str


class SystemPromptResponse(BaseModel):
    prompt_uuid: str
    name: str
    prompt_text: str
    created_at: int


# Startup/Shutdown Events
@app.on_event("startup")
async def startup_event():
    """Initialize Milvus connection and collections on startup"""
    milvus_client.connect()
    milvus_client.create_collection()
    milvus_client.create_chat_history_collection()
    milvus_client.create_contents_collection()
    milvus_client.create_sys_prompts_collection()


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    milvus_client.disconnect()


# API Endpoints
@app.get("/")
async def root():
    return {"message": "RAG Chatbot API is running"}


@app.post("/chat/new", response_model=NewChatResponse)
async def create_new_chat():
    """
    Create a new chat session and return a unique chat ID.
    """
    chat_id = milvus_client.generate_chat_id()
    return NewChatResponse(chat_id=chat_id)


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Handle chat request with RAG or Analytics agent.

    1. Embed the user query
    2. Search Milvus for relevant context
    3. Generate response using AI model with context
    4. Save to chat history
    5. Return response with sources

    Example Analytics Response with Multiple Highcharts:
    {
        "text": "## Sales Analysis\n\nHere's the breakdown of sales by region and monthly trends:",
        "charts": [
            {
                "chart": {"type": "pie"},
                "title": {"text": "Sales Distribution by Region"},
                "series": [{
                    "name": "Sales",
                    "data": [
                        {"name": "North", "y": 45.5},
                        {"name": "South", "y": 28.3},
                        {"name": "East", "y": 16.2},
                        {"name": "West", "y": 10.0}
                    ]
                }]
            },
            {
                "chart": {"type": "column"},
                "title": {"text": "Monthly Revenue"},
                "xAxis": {"categories": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]},
                "series": [{
                    "name": "Revenue",
                    "data": [29.9, 71.5, 106.4, 129.2, 144.0, 176.0]
                }]
            }
        ],
        "attachments": [
            {"filename": "report.pdf", "url": "https://example.com/files/report.pdf"},
            {"filename": "data.xlsx", "url": "https://example.com/files/data.xlsx"}
        ]
    }
    """
    try:
        # Embed the user query
        # query_embedding = await ai_model.embed(request.message)

        # # Search for relevant context
        # search_results = milvus_client.search(query_embedding, top_k=5)

        # # Prepare context from search results
        # context = "\n\n".join([
        #     f"Source: {result['filename']} (Page {result['page_number']})\n{result['text']}"
        #     for result in search_results
        # ])

        # # Get chat history for context
        # chat_history = milvus_client.get_chat_history(request.chat_id)
        # messages = []

        # # Add system prompt if provided
        # if request.system_prompt_uuid:
        #     system_prompt_data = milvus_client.get_system_prompt(request.system_prompt_uuid)
        #     if system_prompt_data:
        #         messages.append({"role": "system", "content": system_prompt_data["prompt_text"]})

        # # Add previous messages to context (last 5 exchanges)
        # for msg in chat_history[-10:]:
        #     messages.append({"role": "user", "content": msg["user_query"]})
        #     messages.append({"role": "assistant", "content": msg["model_response"]})

        # # Add current message
        # messages.append({"role": "user", "content": request.message})

        # # Generate response
        # response = await ai_model.chat(messages=messages, context=context)

        # Create full response structure for saving to history
        # full_response_for_history = {
        #     "text": dummy_response_text,
        #     "charts": dummy_charts,
        #     "attachments": dummy_attachments
        # }

        # # Save complete response to chat history as JSON
        # milvus_client.save_chat_message(
        #     chat_id=request.chat_id,
        #     user_query=request.message,
        #     model_response=json.dumps(full_response_for_history),
        #     agent=request.agent,
        #     spec_id=request.spec_id or ""
        # )

        # # Prepare sources for response
        # sources = [
        #     {
        #         "filename": result["filename"],
        #         "page_number": result["page_number"],
        #         "text_preview": result["text"][:200] + "..."
        #     }
        #     for result in search_results[:3]
        # ]

        

        # return ChatResponse(
        #     chat_id=request.chat_id,
        #     response=response,
        #     sources=sources
        # )

        # Create complete dummy response with all fields populated
                # Generate dummy response text with markdown formatting
        dummy_response_text = """## Analysis Results

Based on the analysis of your query, here are the key findings:

### Executive Summary
The data indicates strong performance across all regions with North America leading at 45.5% of total sales. Revenue trends show consistent growth year-over-year, with 2024 outperforming 2023 by an average of 18.3%.

### Key Insights

1. **Regional Performance**
- North America continues to dominate with 45.5% market share
- Europe shows steady growth at 28.3%
- Asia Pacific represents emerging opportunities at 16.2%
- Latin America has potential for expansion at 10.0%

2. **Revenue Trends**
- Q2 2024 shows exceptional growth (176.0k in June)
- Seasonal patterns indicate strong mid-year performance
- Year-over-year comparison reveals 15-20% growth across most months

3. **Strategic Recommendations**
- Maintain investment in North American operations
- Explore expansion opportunities in Asia Pacific
- Develop targeted campaigns for Latin American markets
- Continue monitoring monthly trends for early indicators

### Supporting Documentation
Please refer to the attached reports and source documents for detailed analysis and raw data.

**Note:** All metrics are based on the latest available data and have been validated against multiple sources."""
        
        dummy_sources = [
            {
                "filename": "product_specifications.pdf",
                "page_number": 15,
                "text_preview": "The system architecture is designed to handle high-volume transactions with a distributed microservices approach. Each service is independently scalable and communicates via REST APIs..."
            },
            {
                "filename": "technical_requirements.pdf",
                "page_number": 8,
                "text_preview": "Performance metrics indicate that the application must support at least 10,000 concurrent users with response times under 200ms for 95% of requests. Database optimization is critical..."
            },
            {
                "filename": "user_manual.pdf",
                "page_number": 42,
                "text_preview": "Authentication follows OAuth 2.0 standards with JWT tokens. Session management includes automatic refresh mechanisms and secure token storage. Multi-factor authentication is supported..."
            }
        ]

        dummy_charts = [
            {
                "chart": {"type": "pie"},
                "title": {"text": "Sales Distribution by Region"},
                "tooltip": {
                    "pointFormat": "{series.name}: <b>{point.percentage:.1f}%</b>"
                },
                "plotOptions": {
                    "pie": {
                        "allowPointSelect": True,
                        "cursor": "pointer",
                        "dataLabels": {
                            "enabled": True,
                            "format": "<b>{point.name}</b>: {point.percentage:.1f} %"
                        }
                    }
                },
                "series": [{
                    "name": "Sales",
                    "colorByPoint": True,
                    "data": [
                        {"name": "North America", "y": 45.5},
                        {"name": "Europe", "y": 28.3},
                        {"name": "Asia Pacific", "y": 16.2},
                        {"name": "Latin America", "y": 10.0}
                    ]
                }]
            },
            {
                "chart": {"type": "column"},
                "title": {"text": "Monthly Revenue Trend"},
                "xAxis": {
                    "categories": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug"],
                    "crosshair": True
                },
                "yAxis": {
                    "min": 0,
                    "title": {
                        "text": "Revenue ($1000s)"
                    }
                },
                "tooltip": {
                    "headerFormat": "<span style='font-size:10px'>{point.key}</span><table>",
                    "pointFormat": "<tr><td style='color:{series.color};padding:0'>{series.name}: </td><td style='padding:0'><b>${point.y:.1f}k</b></td></tr>",
                    "footerFormat": "</table>",
                    "shared": True,
                    "useHTML": True
                },
                "plotOptions": {
                    "column": {
                        "pointPadding": 0.2,
                        "borderWidth": 0
                    }
                },
                "series": [
                    {
                        "name": "2024",
                        "data": [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5]
                    },
                    {
                        "name": "2023",
                        "data": [38.4, 52.3, 86.2, 98.7, 115.3, 142.8, 120.4, 130.2]
                    }
                ]
            }
        ]

        dummy_attachments = [
            {"filename": "sales_report_q3.pdf", "url": "https://example.com/files/sales_report_q3.pdf"},
            {"filename": "revenue_data.xlsx", "url": "https://example.com/files/revenue_data.xlsx"},
            {"filename": "market_analysis.docx", "url": "https://example.com/files/market_analysis.docx"}
        ]

        

        response_obj = ChatResponse(
            chat_id=request.chat_id,
            response=dummy_response_text,
            sources=dummy_sources,
            charts=dummy_charts,
            attachments=dummy_attachments
        )

        response_dict = response_obj.model_dump()

        return JSONResponse(content=response_dict)

    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/upload", response_model=UploadResponse)
async def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    metadata: str = Form("{}")
):
    """
    Upload and process a PDF document.

    Flow:
    1. Validate and read file
    2. Save to contents collection with 'processing' status
    3. Return immediately with UUID and status
    4. Process in background (chunk, embed, store vectors)
    5. Update status to 'completed' when done

    Args:
        file: PDF file to upload
        metadata: JSON string with metadata key-value pairs
    """
    try:
        if not file.filename.endswith('.pdf'):
            raise HTTPException(status_code=400, detail="Only PDF files are supported")

        try:
            metadata_dict = json.loads(metadata)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON metadata")

        file_content = await file.read()

        content_uuid = milvus_client.save_content(file.filename, file_content)

        background_tasks.add_task(
            process_document_async,
            file_content=file_content,
            filename=file.filename,
            metadata=metadata_dict,
            content_uuid=content_uuid,
            ai_model=ai_model,
            milvus_client=milvus_client
        )

        return UploadResponse(
            success=True,
            message=f"File uploaded successfully. Processing started.",
            filename=file.filename,
            content_uuid=content_uuid,
            status="processing"
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/chat/{chat_id}/history")
async def get_history(chat_id: str):
    """
    Retrieve chat history for a specific chat session.
    Returns array of all user queries and model responses with their structure
    (markdown text, charts array, and attachments).
    """
    try:
        history = milvus_client.get_chat_history(chat_id)

        messages = []
        for msg in history:
            response_content = msg["model_response"]

            try:
                response_json = json.loads(response_content)
                if isinstance(response_json, dict):
                    messages.append({
                        "role": "user",
                        "content": msg["user_query"],
                        "timestamp": msg["timestamp"]
                    })
                    messages.append({
                        "role": "assistant",
                        "content": response_json.get("text", response_content),
                        "charts": response_json.get("charts", []),
                        "attachments": response_json.get("attachments"),
                        "timestamp": msg["timestamp"]
                    })
                else:
                    messages.append({
                        "role": "user",
                        "content": msg["user_query"],
                        "timestamp": msg["timestamp"]
                    })
                    messages.append({
                        "role": "assistant",
                        "content": response_content,
                        "timestamp": msg["timestamp"]
                    })
            except json.JSONDecodeError:
                messages.append({
                    "role": "user",
                    "content": msg["user_query"],
                    "timestamp": msg["timestamp"]
                })
                messages.append({
                    "role": "assistant",
                    "content": response_content,
                    "timestamp": msg["timestamp"]
                })

        return {"chat_id": chat_id, "messages": messages}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/chat/sessions")
async def get_chat_sessions(limit: int = 10):
    """
    Retrieve list of chat sessions with their names and timestamps.
    Returns latest 10 sessions by default.
    """
    try:
        sessions = milvus_client.get_all_chat_sessions(limit=limit)
        return {"sessions": sessions, "total": len(sessions)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/content/{content_uuid}/status")
async def get_content_status(content_uuid: str):
    """
    Get the status of an uploaded content by UUID.
    """
    try:
        content = milvus_client.get_content_by_uuid(content_uuid)
        if not content:
            raise HTTPException(status_code=404, detail="Content not found")
        return content
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/contents")
async def list_contents(status: Optional[str] = None, search: Optional[str] = None):
    """
    List all contents with optional filtering.

    Query parameters:
    - status: Filter by status (processing, completed, failed, all)
    - search: Search by filename
    """
    try:
        contents = milvus_client.list_contents(status_filter=status, search_query=search)
        return {"contents": contents, "total": len(contents)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/content/{content_uuid}")
async def delete_content(content_uuid: str):
    """
    Delete content and all associated embeddings.

    This will:
    1. Delete all embeddings from docs_vector collection
    2. Delete the content record from contents collection
    """
    try:
        success = milvus_client.delete_content(content_uuid)
        if not success:
            raise HTTPException(status_code=404, detail="Content not found or deletion failed")
        return {"success": True, "message": "Content deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/system-prompts")
async def create_system_prompt(request: SystemPromptRequest):
    """
    Create a new system prompt.
    """
    try:
        prompt_uuid = milvus_client.create_system_prompt(request.name, request.prompt_text)
        return {"success": True, "prompt_uuid": prompt_uuid, "message": "System prompt created successfully"}
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/system-prompts")
async def list_system_prompts(search: Optional[str] = None):
    """
    List all system prompts with optional search.

    Query parameters:
    - search: Search by name
    """
    try:
        prompts = milvus_client.list_system_prompts(search_query=search)
        return {"prompts": prompts, "total": len(prompts)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/system-prompts/{prompt_uuid}")
async def get_system_prompt(prompt_uuid: str):
    """
    Get a system prompt by UUID.
    """
    try:
        prompt = milvus_client.get_system_prompt(prompt_uuid)
        if not prompt:
            raise HTTPException(status_code=404, detail="System prompt not found")
        return prompt
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/system-prompts/{prompt_uuid}")
async def update_system_prompt(prompt_uuid: str, request: SystemPromptRequest):
    """
    Update a system prompt by UUID.
    """
    try:
        success = milvus_client.update_system_prompt(prompt_uuid, request.name, request.prompt_text)
        if not success:
            raise HTTPException(status_code=404, detail="System prompt not found or update failed")
        return {"success": True, "message": "System prompt updated successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/system-prompts/{prompt_uuid}")
async def delete_system_prompt(prompt_uuid: str):
    """
    Delete a system prompt.
    """
    try:
        success = milvus_client.delete_system_prompt(prompt_uuid)
        if not success:
            raise HTTPException(status_code=404, detail="System prompt not found or deletion failed")
        return {"success": True, "message": "System prompt deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
