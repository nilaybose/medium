import { useState, useRef, useEffect } from 'react';
import { Send, Plus, Loader2, Download, ChevronLeft, ChevronRight, MessageSquare, ChevronDown, ChevronUp, FileText } from 'lucide-react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { api, SystemPrompt } from '../api';
import { Message } from '../types';

interface ChatSession {
  chat_id: string;
  chat_name: string;
  first_timestamp: number;
  last_timestamp: number;
}

interface ContentSpec {
  content_uuid: string;
  filename: string;
  status: string;
  created_at: number;
}

export default function ChatTab() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [chatId, setChatId] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [systemPrompts, setSystemPrompts] = useState<SystemPrompt[]>([]);
  const [selectedPromptUuid, setSelectedPromptUuid] = useState<string>('');
  const [selectedAgent, setSelectedAgent] = useState<string>('RAG');
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [specs, setSpecs] = useState<ContentSpec[]>([]);
  const [selectedSpecId, setSelectedSpecId] = useState<string>('');
  const [expandedSources, setExpandedSources] = useState<{[key: number]: boolean}>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const isHTML = (str: string) => {
    // A simple regex to detect if the string contains common HTML tags.
    // This is not foolproof but should cover most cases.
    const htmlRegex = /<[a-z][\s\S]*>/i;
    return htmlRegex.test(str);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    loadSystemPrompts();
    loadChatSessions();
    loadSpecs();
  }, []);

  const loadSystemPrompts = async () => {
    try {
      const response = await api.listSystemPrompts();
      setSystemPrompts(response.prompts);
    } catch (error) {
      console.error('Error loading system prompts:', error);
    }
  };

  const loadSpecs = async () => {
    try {
      const response = await api.listContents('completed');
      setSpecs(response.contents);
    } catch (error) {
      console.error('Error loading specs:', error);
    }
  };

  const loadChatSessions = async () => {
    try {
      const response = await api.getChatSessions(10);
      setChatSessions(response.sessions);
    } catch (error) {
      console.error('Error loading chat sessions:', error);
    }
  };

  const loadChatHistory = async (selectedChatId: string) => {
    try {
      setLoading(true);
      const response = await api.getChatHistory(selectedChatId);
      const loadedMessages: Message[] = response.messages.map((msg: any) => ({
        role: msg.role,
        content: msg.content,
        charts: msg.charts,
        attachments: msg.attachments,
      }));
      setMessages(loadedMessages);
      setChatId(selectedChatId);
    } catch (error) {
      console.error('Error loading chat history:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNewChat = async () => {
    console.log('Attempting to create new chat...');
    try {
      const response = await api.createNewChat();
      console.log('New chat created:', response);
      setChatId(response.chat_id);
      setMessages([]);
      loadChatSessions();
    } catch (error) {
      console.error('Error creating new chat:', error);
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || loading) return;

    if (!chatId) {
      await handleNewChat();
      return;
    }

    const userMessage: Message = {
      role: 'user',
      content: input,
    };

    setMessages((prev) => {
      const newMessages = [...prev, userMessage];
      console.log('Messages after user message:', newMessages);
      return newMessages;
    });
    setInput('');
    setLoading(true);

    try {
      console.log('Sending message with chatId:', chatId, 'input:', input);
      const response = await api.sendMessage(
        chatId,
        input,
        selectedPromptUuid || undefined,
        selectedAgent,
        selectedAgent === 'RAG' ? selectedSpecId || undefined : undefined
      );
      console.log('Message sent, API response:', response);

      console.log('Backend response:', response);
      console.log('Response content type:', typeof response.response);
      console.log('Response content preview:', response.response?.substring(0, 200));
      console.log('Charts from backend:', response.charts);
      console.log('Attachments from backend:', response.attachments);

      const assistantMessage: Message = {
        role: 'assistant',
        content: response.response,
        sources: response.sources,
        charts: response.charts,
        attachments: response.attachments,
      };

      console.log('Assistant message:', assistantMessage);
      console.log('Message content for rendering:', assistantMessage.content);
      setMessages((prev) => {
        const newMessages = [...prev, assistantMessage];
        console.log('Messages after assistant message:', newMessages);
        return newMessages;
      });
      loadChatSessions();
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: Message = {
        role: 'assistant',
        content: 'Sorry, there was an error processing your request.',
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const groupSessionsByDate = (sessions: ChatSession[]) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const lastWeek = new Date(today);
    lastWeek.setDate(lastWeek.getDate() - 7);

    const groups: { [key: string]: ChatSession[] } = {
      Today: [],
      Yesterday: [],
      'Last 7 Days': [],
      Older: [],
    };

    sessions.forEach((session) => {
      const sessionDate = new Date(session.last_timestamp);
      sessionDate.setHours(0, 0, 0, 0);

      if (sessionDate.getTime() === today.getTime()) {
        groups.Today.push(session);
      } else if (sessionDate.getTime() === yesterday.getTime()) {
        groups.Yesterday.push(session);
      } else if (sessionDate >= lastWeek) {
        groups['Last 7 Days'].push(session);
      } else {
        groups.Older.push(session);
      }
    });

    return groups;
  };

  const sessionGroups = groupSessionsByDate(chatSessions);

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      {sidebarOpen && (
        <div className="w-80 border-r border-gray-200 bg-gray-50 flex flex-col">
          <div className="p-4 border-b border-gray-200 bg-white flex items-center justify-between">
            <h3 className="font-semibold text-gray-800">Chat History</h3>
            <button
              onClick={() => setSidebarOpen(false)}
              className="p-1 hover:bg-gray-100 rounded"
            >
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {Object.entries(sessionGroups).map(([groupName, sessions]) => {
              if (sessions.length === 0) return null;
              return (
                <div key={groupName}>
                  <h4 className="text-xs font-semibold text-gray-500 uppercase mb-2">
                    {groupName}
                  </h4>
                  <div className="space-y-1">
                    {sessions.map((session) => (
                      <button
                        key={session.chat_id}
                        onClick={() => loadChatHistory(session.chat_id)}
                        className={`w-full text-left px-3 py-2 rounded-lg hover:bg-white transition-colors ${
                          chatId === session.chat_id
                            ? 'bg-white border border-blue-200'
                            : 'bg-gray-100'
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          <MessageSquare className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-gray-700 line-clamp-2">
                            {session.chat_name}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {!sidebarOpen && (
          <button
            onClick={() => setSidebarOpen(true)}
            className="absolute left-4 top-4 p-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 shadow-sm z-10"
          >
            <ChevronRight className="w-5 h-5 text-gray-600" />
          </button>
        )}

        {/* Header */}
        <div className="border-b border-gray-200 bg-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">Chat</h2>
            {chatId && (
              <p className="text-sm text-gray-500">Session: {chatId.slice(0, 8)}...</p>
            )}
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium text-gray-700">Agent:</label>
              <select
                value={selectedAgent}
                onChange={(e) => setSelectedAgent(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm min-w-[150px]"
              >
                <option value="RAG">RAG</option>
                <option value="Analytics">Analytics</option>
              </select>
            </div>
            {selectedAgent === 'RAG' && (
              <div className="flex items-center gap-3">
                <label className="text-sm font-medium text-gray-700">Specs:</label>
                <select
                  value={selectedSpecId}
                  onChange={(e) => setSelectedSpecId(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm min-w-[200px]"
                >
                  <option value="">All Specs</option>
                  {specs.map((spec) => (
                    <option key={spec.content_uuid} value={spec.content_uuid}>
                      {spec.filename}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium text-gray-700">System Prompt:</label>
              <select
                value={selectedPromptUuid}
                onChange={(e) => setSelectedPromptUuid(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm min-w-[200px]"
              >
                <option value="">None</option>
                {systemPrompts.map((prompt) => (
                  <option key={prompt.prompt_uuid} value={prompt.prompt_uuid}>
                    {prompt.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
        <button
          onClick={handleNewChat}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Chat
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <p className="text-lg mb-2">No messages yet</p>
              <p className="text-sm">Start a new chat to begin</p>
            </div>
          </div>
        ) : (
          messages.map((message, index) => {
            if (message.role === 'assistant') {
              console.log(`Rendering message ${index}:`, message);
            }
            return (
              <div
                key={index}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
              <div
                className={`max-w-3xl rounded-lg px-4 py-3 ${
                  message.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border border-gray-200 text-gray-800'
                }`}
              >
                {message.role === 'user' ? (
                  <p className="whitespace-pre-wrap break-words">{message.content}</p>
                ) : (
                  <div className="markdown-content break-words overflow-wrap-anywhere">
                    {isHTML(message.content || '') ? (
                      <div dangerouslySetInnerHTML={{ __html: message.content || '' }} />
                    ) : (
                      <ReactMarkdown
                        remarkPlugins={[remarkGfm]}
                        components={{
                          h1: ({...props}) => <h1 className="text-2xl font-bold mt-6 mb-3 text-gray-900" {...props} />,
                          h2: ({...props}) => <h2 className="text-xl font-bold mt-5 mb-2 text-gray-900" {...props} />,
                          h3: ({...props}) => <h3 className="text-lg font-semibold mt-4 mb-2 text-gray-800" {...props} />,
                          h4: ({...props}) => <h4 className="text-base font-semibold mt-3 mb-2 text-gray-800" {...props} />,
                          p: ({...props}) => <p className="mb-3 leading-relaxed text-gray-800" {...props} />,
                          ul: ({...props}) => <ul className="list-disc ml-6 mb-3 space-y-1 text-gray-800" {...props} />,
                          ol: ({...props}) => <ol className="list-decimal ml-6 mb-3 space-y-1 text-gray-800" {...props} />,
                          li: ({...props}) => <li className="leading-relaxed" {...props} />,
                          strong: ({...props}) => <strong className="font-semibold text-gray-900" {...props} />,
                          em: ({...props}) => <em className="italic" {...props} />,
                          code: ({inline, className, children, ...props}: any) => {
                            return inline ? (
                              <code className="bg-gray-100 px-1.5 py-0.5 rounded text-sm font-mono text-gray-800" {...props}>
                                {children}
                              </code>
                            ) : (
                              <code className="block bg-gray-100 p-3 rounded text-sm font-mono text-gray-800 overflow-x-auto my-2" {...props}>
                                {children}
                              </code>
                            );
                          },
                          pre: ({...props}) => (
                            <pre className="bg-gray-100 p-3 rounded my-3 overflow-x-auto" {...props} />
                          ),
                          blockquote: ({...props}) => (
                            <blockquote className="border-l-4 border-gray-300 pl-4 italic text-gray-700 my-3" {...props} />
                          ),
                          a: ({...props}) => (
                            <a className="text-blue-600 hover:text-blue-800 underline" target="_blank" rel="noopener noreferrer" {...props} />
                          ),
                        }}
                      >
                        {String(message.content || '')}
                      </ReactMarkdown>
                    )}
                  </div>
                )}

                {message.charts && message.charts.length > 0 && (
                  <div className="mt-4 space-y-4">
                    {message.charts.map((chart, chartIndex) => {
                      console.log(`Rendering chart ${chartIndex}:`, chart);
                      return (
                        <div key={chartIndex} className="border border-gray-200 rounded-lg p-4 bg-white">
                          <HighchartsReact highcharts={Highcharts} options={chart} />
                        </div>
                      );
                    })}
                  </div>
                )}

                {message.attachments && message.attachments.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <p className="text-sm font-semibold mb-2 text-gray-600">Attachments:</p>
                    <div className="space-y-2">
                      {message.attachments.map((attachment, idx) => (
                        <a
                          key={idx}
                          href={attachment.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 hover:underline bg-blue-50 p-2 rounded transition-colors"
                        >
                          <Download className="w-4 h-4" />
                          {attachment.filename}
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {message.sources && message.sources.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <button
                      onClick={() => setExpandedSources(prev => ({
                        ...prev,
                        [index]: !prev[index]
                      }))}
                      className="flex items-center gap-2 text-sm font-semibold text-gray-700 hover:text-gray-900 transition-colors w-full"
                    >
                      <FileText className="w-4 h-4" />
                      <span>Sources ({message.sources.length})</span>
                      {expandedSources[index] ? (
                        <ChevronUp className="w-4 h-4 ml-auto" />
                      ) : (
                        <ChevronDown className="w-4 h-4 ml-auto" />
                      )}
                    </button>

                    {expandedSources[index] && (
                      <div className="mt-2 space-y-2">
                        {message.sources.map((source, idx) => (
                          <div key={idx} className="text-sm text-gray-600 bg-gray-50 p-3 rounded border border-gray-200">
                            <p className="font-medium text-gray-800">
                              {source.filename} (Page {source.page_number})
                            </p>
                            <p className="text-xs mt-1 text-gray-600">{source.text_preview}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            );
          })
        )}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border border-gray-200 rounded-lg px-4 py-3">
              <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

        {/* Input */}
        <div className="border-t border-gray-200 bg-white px-6 py-4">
          <div className="flex gap-3">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1 resize-none rounded-lg border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={1}
              disabled={loading}
            />
            <button
              onClick={handleSendMessage}
              disabled={loading || !input.trim()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
