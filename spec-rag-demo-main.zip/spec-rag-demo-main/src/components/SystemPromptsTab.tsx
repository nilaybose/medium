import { useState } from 'react';
import { Search, Plus, Trash2, Loader2, FileText, X, Eye, CreditCard as Edit } from 'lucide-react';
import { api, SystemPrompt } from '../api';

export function SystemPromptsTab() {
  const [prompts, setPrompts] = useState<SystemPrompt[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [deletingUuid, setDeletingUuid] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newPromptName, setNewPromptName] = useState('');
  const [newPromptText, setNewPromptText] = useState('');
  const [creating, setCreating] = useState(false);
  const [expandedUuid, setExpandedUuid] = useState<string | null>(null);
  const [viewModalPrompt, setViewModalPrompt] = useState<SystemPrompt | null>(null);
  const [editModalPrompt, setEditModalPrompt] = useState<SystemPrompt | null>(null);
  const [editName, setEditName] = useState('');
  const [editText, setEditText] = useState('');
  const [updating, setUpdating] = useState(false);

  const fetchPrompts = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.listSystemPrompts(searchQuery);
      setPrompts(response.prompts);
    } catch (err) {
      setError('Failed to load system prompts');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setHasSearched(true);
    fetchPrompts();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleDelete = async (promptUuid: string, name: string) => {
    if (!confirm(`Are you sure you want to delete "${name}"?`)) {
      return;
    }

    try {
      setDeletingUuid(promptUuid);
      await api.deleteSystemPrompt(promptUuid);
      setPrompts(prompts.filter(p => p.prompt_uuid !== promptUuid));
    } catch (err) {
      setError('Failed to delete system prompt');
      console.error(err);
    } finally {
      setDeletingUuid(null);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newPromptName.trim() || !newPromptText.trim()) {
      setError('Name and prompt text are required');
      return;
    }

    try {
      setCreating(true);
      setError(null);
      await api.createSystemPrompt({
        name: newPromptName,
        prompt_text: newPromptText,
      });
      setShowAddModal(false);
      setNewPromptName('');
      setNewPromptText('');
      if (hasSearched) {
        fetchPrompts();
      }
    } catch (err) {
      setError('Failed to create system prompt');
      console.error(err);
    } finally {
      setCreating(false);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const toggleExpand = (uuid: string) => {
    setExpandedUuid(expandedUuid === uuid ? null : uuid);
  };

  const openViewModal = (prompt: SystemPrompt) => {
    setViewModalPrompt(prompt);
  };

  const closeViewModal = () => {
    setViewModalPrompt(null);
  };

  const openEditModal = (prompt: SystemPrompt) => {
    setEditModalPrompt(prompt);
    setEditName(prompt.name);
    setEditText(prompt.prompt_text);
  };

  const closeEditModal = () => {
    setEditModalPrompt(null);
    setEditName('');
    setEditText('');
    setError(null);
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!editName.trim() || !editText.trim()) {
      setError('Name and prompt text are required');
      return;
    }

    if (!editModalPrompt) return;

    try {
      setUpdating(true);
      setError(null);
      await api.updateSystemPrompt(editModalPrompt.prompt_uuid, {
        name: editName,
        prompt_text: editText,
      });
      closeEditModal();
      fetchPrompts();
    } catch (err) {
      setError('Failed to update system prompt');
      console.error(err);
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="mb-6 flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">System Prompts</h2>
          <p className="text-gray-600">Manage system prompts for your chatbot</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Add Prompt
        </button>
      </div>

      <div className="mb-6 flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <button
          onClick={handleSearch}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Search
        </button>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      <div className="flex-1 overflow-auto bg-white rounded-lg border border-gray-200">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
          </div>
        ) : !hasSearched ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <Search className="w-16 h-16 mb-4 text-gray-300" />
            <p className="text-lg">Search to view system prompts</p>
            <p className="text-sm mt-2">Use the search above to find prompts</p>
          </div>
        ) : prompts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <FileText className="w-16 h-16 mb-4 text-gray-300" />
            <p className="text-lg">No system prompts found</p>
            <p className="text-sm mt-2">Create your first system prompt to get started</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {prompts.map((prompt) => (
              <div key={prompt.prompt_uuid} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex justify-between items-start gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {prompt.name}
                    </h3>
                    <div className="mb-3">
                      <div
                        className={`text-sm text-gray-600 ${
                          expandedUuid === prompt.prompt_uuid ? '' : 'line-clamp-2'
                        }`}
                      >
                        {prompt.prompt_text}
                      </div>
                      {prompt.prompt_text.length > 150 && (
                        <button
                          onClick={() => toggleExpand(prompt.prompt_uuid)}
                          className="text-sm text-blue-600 hover:text-blue-800 mt-1"
                        >
                          {expandedUuid === prompt.prompt_uuid ? 'Show less' : 'Show more'}
                        </button>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-xs text-gray-400">
                      <span>Created: {formatDate(prompt.created_at)}</span>
                      <span>UUID: {prompt.prompt_uuid.substring(0, 8)}...</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => openViewModal(prompt)}
                      className="text-gray-600 hover:text-gray-800 transition-colors"
                      title="View prompt"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => openEditModal(prompt)}
                      className="text-blue-600 hover:text-blue-800 transition-colors"
                      title="Edit prompt"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(prompt.prompt_uuid, prompt.name)}
                      disabled={deletingUuid === prompt.prompt_uuid}
                      className="text-red-600 hover:text-red-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      title="Delete prompt"
                    >
                      {deletingUuid === prompt.prompt_uuid ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <Trash2 className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {hasSearched && (
        <div className="mt-4 text-sm text-gray-500">
          Showing {prompts.length} prompt{prompts.length !== 1 ? 's' : ''}
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xl font-semibold text-gray-900">Add System Prompt</h3>
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    setNewPromptName('');
                    setNewPromptText('');
                    setError(null);
                  }}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleCreate}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    value={newPromptName}
                    onChange={(e) => setNewPromptName(e.target.value)}
                    placeholder="Enter prompt name"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Prompt Text
                  </label>
                  <textarea
                    value={newPromptText}
                    onChange={(e) => setNewPromptText(e.target.value)}
                    placeholder="Enter system prompt text"
                    rows={8}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    required
                  />
                </div>

                <div className="flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddModal(false);
                      setNewPromptName('');
                      setNewPromptText('');
                      setError(null);
                    }}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creating}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    {creating ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      <>
                        <Plus className="w-5 h-5" />
                        Create Prompt
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {viewModalPrompt && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full mx-4 max-h-[90vh] overflow-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{viewModalPrompt.name}</h3>
                  <div className="flex items-center gap-4 text-xs text-gray-400 mt-2">
                    <span>Created: {formatDate(viewModalPrompt.created_at)}</span>
                    <span>UUID: {viewModalPrompt.prompt_uuid}</span>
                  </div>
                </div>
                <button
                  onClick={closeViewModal}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Prompt Text
                </label>
                <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 whitespace-pre-wrap text-sm text-gray-800 max-h-96 overflow-y-auto">
                  {viewModalPrompt.prompt_text}
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <button
                  onClick={() => {
                    closeViewModal();
                    openEditModal(viewModalPrompt);
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Edit className="w-5 h-5" />
                  Edit
                </button>
                <button
                  onClick={closeViewModal}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {editModalPrompt && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xl font-semibold text-gray-900">Edit System Prompt</h3>
                <button
                  onClick={closeEditModal}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleUpdate}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    placeholder="Enter prompt name"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Prompt Text
                  </label>
                  <textarea
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    placeholder="Enter system prompt text"
                    rows={12}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    required
                  />
                </div>

                <div className="flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={closeEditModal}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={updating}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    {updating ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Updating...
                      </>
                    ) : (
                      <>
                        <Edit className="w-5 h-5" />
                        Update Prompt
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
