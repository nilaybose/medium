const API_BASE_URL = 'http://localhost:8000';

export interface ChatRequest {
  chat_id: string;
  message: string;
}

export interface ChatResponse {
  chat_id: string;
  response: string;
  sources: Array<{
    filename: string;
    page_number: number;
    text_preview: string;
  }>;
  charts?: any[];
  attachments?: Array<{
    filename: string;
    url: string;
  }>;
}

export interface NewChatResponse {
  chat_id: string;
}

export interface UploadResponse {
  success: boolean;
  message: string;
  filename: string;
  content_uuid: string;
  status: string;
}

export interface Content {
  content_uuid: string;
  filename: string;
  status: string;
  created_at: number;
}

export interface ContentsListResponse {
  contents: Content[];
  total: number;
}

export interface SystemPrompt {
  prompt_uuid: string;
  name: string;
  prompt_text: string;
  created_at: number;
}

export interface SystemPromptsListResponse {
  prompts: SystemPrompt[];
  total: number;
}

export interface CreateSystemPromptRequest {
  name: string;
  prompt_text: string;
}

export const api = {
  async createNewChat(): Promise<NewChatResponse> {
    const response = await fetch(`${API_BASE_URL}/chat/new`, {
      method: 'POST',
    });
    if (!response.ok) throw new Error('Failed to create new chat');
    return response.json();
  },

  async sendMessage(chatId: string, message: string, systemPromptUuid?: string, agent?: string, specId?: string): Promise<ChatResponse> {
    const response = await fetch(`${API_BASE_URL}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message,
        system_prompt_uuid: systemPromptUuid || null,
        agent: agent || 'RAG',
        spec_id: specId || null
      }),
    });
    if (!response.ok) throw new Error('Failed to send message');
    return response.json();
  },

  async uploadDocument(file: File, metadata: Record<string, any>): Promise<UploadResponse> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('metadata', JSON.stringify(metadata));

    const response = await fetch(`${API_BASE_URL}/upload`, {
      method: 'POST',
      body: formData,
    });
    if (!response.ok) throw new Error('Failed to upload document');
    return response.json();
  },

  async getChatHistory(chatId: string): Promise<{ chat_id: string; messages: any[] }> {
    const response = await fetch(`${API_BASE_URL}/chat/${chatId}/history`);
    if (!response.ok) throw new Error('Failed to get chat history');
    return response.json();
  },

  async getChatSessions(limit: number = 10): Promise<{ sessions: any[]; total: number }> {
    const response = await fetch(`${API_BASE_URL}/chat/sessions?limit=${limit}`);
    if (!response.ok) throw new Error('Failed to get chat sessions');
    return response.json();
  },

  async listContents(status?: string, search?: string): Promise<ContentsListResponse> {
    const params = new URLSearchParams();
    if (status && status !== 'all') params.append('status', status);
    if (search) params.append('search', search);

    const url = `${API_BASE_URL}/contents${params.toString() ? '?' + params.toString() : ''}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to list contents');
    return response.json();
  },

  async getContentStatus(contentUuid: string): Promise<Content> {
    const response = await fetch(`${API_BASE_URL}/content/${contentUuid}/status`);
    if (!response.ok) throw new Error('Failed to get content status');
    return response.json();
  },

  async deleteContent(contentUuid: string): Promise<{ success: boolean; message: string }> {
    const response = await fetch(`${API_BASE_URL}/content/${contentUuid}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Failed to delete content');
    return response.json();
  },

  async createSystemPrompt(data: CreateSystemPromptRequest): Promise<{ success: boolean; prompt_uuid: string; message: string }> {
    const response = await fetch(`${API_BASE_URL}/system-prompts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to create system prompt');
    return response.json();
  },

  async listSystemPrompts(search?: string): Promise<SystemPromptsListResponse> {
    const params = new URLSearchParams();
    if (search) params.append('search', search);

    const url = `${API_BASE_URL}/system-prompts${params.toString() ? '?' + params.toString() : ''}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to list system prompts');
    return response.json();
  },

  async getSystemPrompt(promptUuid: string): Promise<SystemPrompt> {
    const response = await fetch(`${API_BASE_URL}/system-prompts/${promptUuid}`);
    if (!response.ok) throw new Error('Failed to get system prompt');
    return response.json();
  },

  async updateSystemPrompt(promptUuid: string, data: CreateSystemPromptRequest): Promise<{ success: boolean; message: string }> {
    const response = await fetch(`${API_BASE_URL}/system-prompts/${promptUuid}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to update system prompt');
    return response.json();
  },

  async deleteSystemPrompt(promptUuid: string): Promise<{ success: boolean; message: string }> {
    const response = await fetch(`${API_BASE_URL}/system-prompts/${promptUuid}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Failed to delete system prompt');
    return response.json();
  },
};
