export interface Message {
  role: 'user' | 'assistant';
  content: string;
  sources?: Source[];
  charts?: any[];
  attachments?: Attachment[];
}

export interface Attachment {
  filename: string;
  url: string;
}

export interface Source {
  filename: string;
  page_number: number;
  text_preview: string;
}

export interface ChatHistory {
  id: string;
  chat_id: string;
  user_query: string;
  model_response: string;
  created_at: string;
}
